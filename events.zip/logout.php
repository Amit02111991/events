<?php
unset($_COOKIE["userName"]);
unset($_COOKIE["userId"]);
$_COOKIE["userName"]    = "";
$_COOKIE["userId"]      = "";
setcookie("userName","",time()-3600,"/");
setcookie("userId","",time()-3600,"/");
header("location:login.php?msg=1");
?>