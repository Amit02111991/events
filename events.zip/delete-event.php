<?php
session_start();
date_default_timezone_set("Asia/Calcutta");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('databaseConnect.php');

$query = "Delete From tblevents where eventId=".$_GET['id'];
mysqli_query($conn, $query) or die(mysqli_error($conn));
mysqli_close($conn);
header('Location: index.php?msg=3');
?>