<?php
ob_start();
if(!isset($_COOKIE["userName"]) || strlen($_COOKIE["userName"]) < 1 || empty($_COOKIE["userName"]))
{
	header("location:login.php?err=4");
	exit;
}
else{
	include "encryption.php";
	$userName	= $test->decrypt(base64_decode($_COOKIE["userName"]));
	$loggedInUserId	= $test->decrypt(base64_decode($_COOKIE["userId"])); 
	$GLOBALS['loggedInUserId'] = $loggedInUserId;	
}
?>