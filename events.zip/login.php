<?php
date_default_timezone_set('Asia/Kolkata');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" type="text/css" href="include/bootstrap.min.css">
        <link href="include/style.css" rel="stylesheet"> 	
	</head>
	<body>	
<section>
  <div class="container"> 
  <!-- .row -->
 <div class="row padding-bottom20">
 <div class="col-sm-3 col-p">              
 </div>
 <div class="col-sm-6 col-p">
  <br>
  
         <div>
			<h2 class="text-center">Login</h2>
		</div>
                      
		<form class="form-signin" method="post" action="auth.php">
		<?php If(isset($_REQUEST["msg"]) && $_REQUEST["msg"] == "1"){ ?>
		 <div class="alert alert-success alert-dismissable">
		   <i class="fa fa-times"></i>
		   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		   You have been logged out successfully
		 </div>
		 <?php } ?>
		<?php If(isset($_REQUEST["err"]) && $_REQUEST["err"] == "1"){ ?>
		 <div class="alert alert-danger alert-dismissable">
		   <i class="fa fa-times"></i>
		   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		   Username Required!
		 </div>
		 <?php } ?>
		 <?php If(isset($_REQUEST["err"]) && $_REQUEST["err"] == "2"){ ?>
		 <div class="alert alert-danger alert-dismissable">
		   <i class="fa fa-times"></i>
		   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		   Password Required!
		 </div>
		 <?php } ?>
		 <?php If(isset($_REQUEST["err"]) && $_REQUEST["err"] == "3"){ ?>
		 <div class="alert alert-danger alert-dismissable">
		   <i class="fa fa-times"></i>
		   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		   <b> Oops!</b> Invalid login credentials.
		 </div>
		 <?php } ?>
		 <?php If(isset($_REQUEST["err"]) && $_REQUEST["err"] == "4"){ ?>
		 <div class="alert alert-danger alert-dismissable">
		   <i class="fa fa-times"></i>
		   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		   <b> Oops!</b> Your session out ! Please login again.
		 </div>
		 <?php } ?>
		 
		  <div class="form-group">
			<label>User Name</label>
			<input name="uname" class="form-control input-block-level" type="text" required />
			</div>
		 
		 <div class="form-group">
			<label>Password</label>
			<input name="pass" class="form-control input-block-level" type="text" required />
			</div>
		
       <div class="box-footer clearfix">
	<input value="Sign In" type="submit" class="btn btn-primary pull-right">
    </div>
    </form>
						
 </div>
 <div class="col-sm-3 col-p">              
 </div> 
</div>
  <!-- .row end --> 
  </div>
</section>
<!-- Section end here ---> 
<hr>
<!-- Footer Section Start here --->
 <footer>
<p style="font-weight:bold;">Copyright &copy; <?php echo date("Y");?> . All rights reserved.</p>
 </footer>
<script src="include/jquery-2.2.3.min.js"></script>
<script src="include/bootstrap.min.js"></script>
</body>
</html>