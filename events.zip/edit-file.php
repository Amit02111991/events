<?php
error_reporting(0);
//include "check-session.php";
$file = $_REQUEST["file"];
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Edit <?=$file;?></title>
		<link rel="stylesheet" type="text/css" href="include/bootstrap.min.css">
		
 <link href="include/style.css" rel="stylesheet"> 		
	</head>
	<body>	
	<section>
	<div class="container"> 
  <!-- .row -->
 <div class="row padding-bottom20">
 <div class="col-sm-1 col-p">              
 </div>
 <div class="col-sm-11 col-p">
 <br>
<?php 
	 $dir = "files";
	$file = $dir."/".$file;
	if(isset($_POST['html']))
    {
	    $postedHTML = $_POST['html'];
		file_put_contents($file, $postedHTML);
		header('Location: index.php');	
	}
	?>	
	 
	 <div class="box">
	  <div class="text-left">
						<h2>Edit [<?=$_REQUEST["file"];?>]</h2>
					</div>
					<div class="text-right">
						<a href="index.php" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Back</a>
						</div>
						
						
						</div>
	                   
						 <br>
									
						
						
	 <form action="" method="post" role="form">
	 <div class="form-group">
	 <?php
		$content = file_get_contents($file);
		echo "<textarea name='html' class='form-control' rows='26' cols='70' id='html'>" . htmlspecialchars($content) . "</textarea>";
    ?>
		</div>
	<div class="box-footer clearfix">
	<input value="Edit Page" type="submit" class="btn btn-primary pull-right">
    </div>
	 </form>
	 
	</div>
 
  </div>
	 
</section>
<!-- Section end here ---> 
<hr>
<script src="include/jquery-2.2.3.min.js"></script>
<script src="include/bootstrap.min.js"></script>
	
	 
</body>
<html>
	 







