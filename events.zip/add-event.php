<?php
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="include/bootstrap.min.css">	
    <link href="include/style.css" rel="stylesheet"> 		
	</head>
	<body>	
	<section>
	<div class="container"> 
  <!-- .row -->
 <div class="row padding-bottom20">
 <div class="col-sm-1 col-p">              
 </div>
 <div class="col-sm-11 col-p">
 <br>

	<div>
	<h2>Add Event <a href="index.php"><button class="pull-right btn btn-primary btn-sm">Back</button></a></h2>						
	</div>
	 <?php
	 if(isset($_REQUEST["msg"]))
		{
			if($_REQUEST["msg"] == "1")
			  {
			  ?>
								<div class='alert alert-success alert-dismissable'>
									<i class='fa fa-check'></i>
									<button type='button' class='close' data-dismiss='alert" aria-hidden='true'>&times;</button>
									Event Added Successfully.
								</div>
			  <?php
			 }
		}
	 ?>
	 <!--<form action="add-event-process.php" method="post" role="form">-->
	 <form action="Javascript:;" role="form">
	 <div class="form-group">
		<label>Event Title</label>
		<input name="eventTitle" id="eventTitle" class="form-control" type="text" value="" />
	</div>
	<div class="form-group">
		<label>Start Date</label>
		<input type="date" name="startDate" id="startDate" class="form-control" title="Start Date" placeholder="Start Date (MM/DD/YY)" required="">
	</div>
	<div class="form-group">
		<label>End Date</label>
		<input type="date" name="endDate" id="endDate" class="form-control" title="Event Date" placeholder="Start Date (MM/DD/YY)" required="">
	</div>
   <div class="form-group form-row">
	   <label>Recurrence </label>
	    <div class="radio">
		  <label>
		  <input type="radio" name="recurrenceType" id="recurrenceType" value="1">Repeat &nbsp;    
		  <div class="form-group">
			  <select name="recurrence1week" id="recurrence1week" class="form-control">
				  <option value="Every">Every</option>
				  <option value="Second">Others</option>
				  <option value="Third">Every Third</option>
			  </select>
			  <select name="recurrence1day" id="recurrence1day" class="form-control">
				  <option value="7">Sunday</option>
				  <option value="1">Monday</option>
				  <option value="2">Tuesday</option>
				  <option value="3">Wednesday</option>
				  <option value="4">Thursday</option>
				  <option value="5">Friday</option>
				  <option value="6">Saturday</option>
			  </select>
		  </div>
		  </label>
		</div>
		<div class="radio">
		  <label><input type="radio" value="2" id="recurrenceType" name="recurrenceType">Repeat on the &nbsp; 
		  <div class="form-group">
			  <select name="recurrence2c" id="recurrence2c" class="form-control">
				  <option value="First">First</option>
				  <option value="Second">Second</option>
				  <option value="Third">Third</option>
				  <option value="Forth">Forth</option>
			  </select>
			  <select name="recurrence2day" id="recurrence2day" class="form-control">
				  <option value="7">Sunday</option>
				  <option value="1">Monday</option>
				  <option value="2">Tuesday</option>
				  <option value="3">Wednesday</option>
				  <option value="4">Thursday</option>
				  <option value="5">Friday</option>
				  <option value="6">Saturday</option>
			  </select>
			  of the
			   <select name="recurrence2month" id="recurrence2month" class="form-control">
				  <option value="Month">Month</option>
				  <option value="3 Months">3 Months</option>
			  </select>
		  </div>
		  </label>
	    </div>
	</div>
	<div class="box-footer clearfix">
	<input value="Add Event" type="submit" onClick="return submitForm();" class="btn btn-primary pull-right">
    </div>
	 </form>
	 
	</div>
  </div>
	 
</section>
<!-- Section end here ---> 
<hr>
<script src="include/jquery-2.2.3.min.js"></script>
<script src="include/bootstrap.min.js"></script>
<script>
function submitForm() 
{
	var eventTitle = $("#eventTitle").val();
	var startDate = $("#startDate").val();
	var endDate = $("#endDate").val();
	var recurrenceType = $('input[name=recurrenceType]:checked').val(); 
	var recurrence1week = $("#recurrence1week").val();
	var recurrence1day = $("#recurrence1day").val();
	var recurrence2c = $("#recurrence2c").val();
	var recurrence2day = $("#recurrence2day").val();
	var recurrence2month = $("#recurrence2month").val();
	
	if(eventTitle == "") {
		alert("Please Enter Title");
		return false;
	}
	
	if(startDate == "")
	{
		alert("Please Select Start Date");
		return false;
    }
	
	if(endDate == "")
	{
		alert("Please Select End Date");
		return false;
    }
	
	if(recurrenceType == "")
	{
		alert("Please Select Recurrence");
		return false;
    }
	
	$.ajax({
			url: "add-event-process.php",
			type: "POST",
			data: {
				eventTitle: eventTitle,
				startDate: startDate,
				endDate: endDate,
				recurrenceType: recurrenceType,
				recurrence1week: recurrence1week,
				recurrence1day: recurrence1day,
				recurrence2c: recurrence2c,
				recurrence2day: recurrence2day,
				recurrence2month: recurrence2month
			},
			success: function(response) {
				response = response.trim();
				if(response == "success") {
					location.href = 'index.php?msg=1';
				} else if(response == "eventTitle") {
					alert("Please Enter Title");
					return false;
				} else if(response == "startDate") {
					alert("Please Select Start Date");
					return false;
				} else if(response == "endDate") {
					alert("Please Select End Date");
					return false;
				} else if(response == "recurrenceType") {
					alert("Please Select Eecurrence");
					return false;
				}
			}
		});
		
}
</script>	
<?php
session_destroy();
?>	
</body>
<html>
	 







