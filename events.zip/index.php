<?php
session_start();
date_default_timezone_set("Asia/Calcutta");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('databaseConnect.php');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" type="text/css" href="include/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="include/jquery.dataTables.min.css">
        <link href="include/style.css" rel="stylesheet"> 
        <link href="fonts/font-awesome/font-awesome.min.css" rel="stylesheet" type="text/css" />		
	</head>
	<body>	
<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container-fluid">
					<div class="nav-collapse" id="menuBar">
					<ul class="nav pull-right">
						<li><a href="logout.php" title="Log Out"><b>Logout</b></a> </li>
						
					</ul>
				</div>
			</div>
		</div>
	</div>
<section>
  <div class="container"> 
  <!-- .row -->
 <div class="row padding-bottom20">
 <div class="col-sm-1 col-p">              
 </div>
 <div class="col-sm-11 col-p"> 
  <br>
                        <div class="text-centet">
						<h2>Event Management</h2>
						</div>
						<?php
						 if(isset($_REQUEST["msg"]))
							{
								if($_REQUEST["msg"] == "1")
								  {
								  ?>
											<div class='alert alert-success alert-dismissable'>
											<i class='fa fa-check'></i>
											<button type='button' class='close' data-dismiss='alert" aria-hidden='true'>&times;</button>
												Event Added Successfully.
										    </div>
								  <?php
								 }
								 if($_REQUEST["msg"] == "2")
								 {
								 ?>
								       <div class='alert alert-success alert-dismissable'>
											<i class='fa fa-check'></i>
											<button type='button' class='close' data-dismiss='alert" aria-hidden='true'>&times;</button>
											Event Update Successfully.
									   </div>
                                 <?php								
								 }
								 if($_REQUEST["msg"] == "3")
								 {
								 ?>
								     <div class='alert alert-success alert-dismissable'>
											<i class='fa fa-check'></i>
											<button type='button' class='close' data-dismiss='alert" aria-hidden='true'>&times;</button>
											Event Delete Successfully.
									   </div>
                                 <?php								 
								 }
							}
						 ?>
						<div class="box">
									<div class="box-tools">
									<div class="text-right">
                                        <a href="add-event.php" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Add Event</a>
									</div>
                                    </div>
						 </div>
						<p>
						<div class="table-responsive">
					    <table class="table table-bordered">
						  <thead>
							<tr>
							  <th scope="col">#</th>
							  <th scope="col">Title</th>
							  <th scope="col">Dates</th>
							  <th scope="col">Recurrence</th>
							  <th scope="col">View</th>
							  <th scope="col">Edit</th>
							  <th scope="col">Delete</th>
							</tr>
						  </thead>
						  <tbody>
						  <?php
						  $sql = "Select * from tblevents order by eventId ASC";
						  $query =  mysqli_query($conn,$sql) or die(mysqli_error($conn));
						  while($rows = mysqli_fetch_array($query))
						  {
						  ?>
						  <tr>
								<th scope="row"><?=$rows['eventId']?></th>
							    <td><?=$rows['eventTitle']?></td>
								<td><?=$rows['startDate']." to ".$rows['endDate']?></td>
								<td><?=$rows['recurrence']?></td>
								<td><a href="view-event.php?id=<?=$rows['eventId']?>"><i class="fa fa-eye"></i></a></td>
								<td><a href="edit-event.php?id=<?=$rows['eventId']?>"><i class="fa fa-pencil"></i></a></td>
								<td><a href="#" onclick="JavaScript:deleteConfirm(<?=$rows['eventId']?>); return false"> <i class="fa fa-trash-o"></i></a></td>
						</tr>
						<?php
						  }
						?>
						  </tbody>
						</table>
					</div>
					
 </div>
 
  </div>
  
  <!-- .row end --> 
  </div>
</section>
<!-- Section end here ---> 
<hr>
<!-- Footer Section Start here --->
	<script src="include/jquery-2.2.3.min.js"></script>
	<script src="include/bootstrap.min.js"></script>
	<script>
	
	function deleteConfirm(id)
	{
		if(confirm("Are you sure you want to delete this event?"))
		{
			location.href = "delete-event.php?id=" + id;
		}
	}
	
	</script>
    </body>
</html>