<?php
session_start();
date_default_timezone_set("Asia/Calcutta");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('databaseConnect.php');
$eventId = $_GET['id'];

if (!is_numeric($eventId)) 
{
	 
	echo "Invalid eventId"; 
	mysqli_close($conn);
	exit;
}

if (strlen($eventId) < 1 && $eventId == 0) 
{
	echo "Invalid eventId"; 
	mysqli_close($conn);
	exit;
}
$query = "select * from tblevents where eventId = ".$eventId;
$result = mysqli_query($conn,$query) or die(mysqli_error($conn));
$line = mysqli_fetch_array($result);
$eventTitle = $line['eventTitle'];


$totalEventQuery = mysqli_query($conn, "Select count(*) as totalEvent From tblevents_recurrences where eventId = ".$eventId);
$totalCreditCard = mysqli_fetch_assoc($totalEventQuery);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" type="text/css" href="include/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="include/jquery.dataTables.min.css">
        <link href="include/style.css" rel="stylesheet"> 
        <link href="fonts/font-awesome/font-awesome.min.css" rel="stylesheet" type="text/css" />		
	</head>
	<body>	
<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container-fluid">
					<div class="nav-collapse" id="menuBar">
					<ul class="nav pull-right">
						<li><a href="logout.php" title="Log Out"><b>Logout</b></a> </li>
						
					</ul>
				</div>
			</div>
		</div>
	</div>
<section>
  <div class="container"> 
  <!-- .row -->
 <div class="row padding-bottom20">
 <div class="col-sm-1 col-p">              
 </div>
 <div class="col-sm-11 col-p"> 
  <br>
                        <div class="text-centet">
						<h2>Event View Page</h2>
						</div>
						<div class="box">
						<div class="box-tools">
						<div class="text-left">
                             <p><?=$eventTitle;?></p>   
						</div>
                        </div>
						</div>
						<p class="text-right">Total Recurrence Event: (<?=$totalCreditCard['totalEvent'];?>)</p>
						<div class="table-responsive">
					    <table class="table table-bordered">
						  <thead>
							<tr>
							  <th scope="col">Date</th>
							  <th scope="col">Day Name</th>
							</tr>
						  </thead>
						  <tbody>
						  <?php
						  $sql = "Select * from tblevents_recurrences where eventId = ".$eventId." ";
						  $query =  mysqli_query($conn,$sql) or die(mysqli_error($conn));
						  while($rows = mysqli_fetch_array($query))
						  {
						  ?>
						  <tr>
								<td><?=$rows['eventDate']?></th>
							    <td><?=$rows['eventDay']?></td>
						</tr>
						<?php
						 }
						?>
						  </tbody>
						</table>
					</div>
					
 </div>
 
  </div>
  
  <!-- .row end --> 
  </div>
</section>
<!-- Section end here ---> 
<hr>
<!-- Footer Section Start here --->
	<script src="include/jquery-2.2.3.min.js"></script>
	<script src="include/bootstrap.min.js"></script>
	<script>
	
	function deleteConfirm(id)
	{
		if(confirm("Are you sure you want to delete this event?"))
		{
			location.href = "delete-event.php?id=" + id;
		}
	}
	
	</script>
    </body>
</html>