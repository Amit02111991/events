<?php
ob_start();
$userName 		= Trim($_REQUEST["uname"]);
$userPassword 	= Trim($_REQUEST["pass"]);
if(strlen($userName) < 1  || empty($userName))
{
	header("location:login.php?err=1");
	exit;
}
if(strlen($userPassword) < 2  || empty($userPassword))
{
	header("location:login.php?err=2");
	exit;
}
$userId		= "777";
$uName  	= "Admin";

if($userName=="admin" && $userPassword=="lmsadmin")
{
	setcookie("userName", $uName);
	setcookie("userId", $userId);
	header("location:index.php");
}
else{
header("location:login.php?err=3");
exit;
}
?>