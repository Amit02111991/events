<?php
session_start();
date_default_timezone_set("Asia/Calcutta");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('databaseConnect.php');
$currentDateTime = date("Y-m-d H:i:s"); 

//function for get Date from week and date
function getDateForDayBetweenDates($startDate,$endDate,$day_number,$ofWeek){
    $endDate = strtotime($endDate);
    $days=array('1'=>'Monday','2' => 'Tuesday','3' => 'Wednesday','4'=>'Thursday','5' =>'Friday','6' => 'Saturday','7'=>'Sunday');
    $date_array = array();
    $cnt=0;
    for($i = strtotime($days[$day_number], strtotime($startDate)); $i <= $endDate; $i = strtotime('+1 week', $i))
    {
        $weeknumber = weekOfMonth(date('Y-m-d',$i));
        //echo "Week : ".$weeknumber.'  -  Date : '.date('Y-m-d',$i)."<br>";
		if($ofWeek == "")
		{
			$date_array[$cnt]['dates']=date('Y-m-d',$i);
			$cnt++;
		}
		else
		{
			if($weeknumber == $ofWeek){
				$date_array[$cnt]['dates']=date('Y-m-d',$i);
				$cnt++;
			}
		}
    }
	return $date_array;
}
function weekOfMonth($date) {
    // estract date parts
    list($y, $m, $d) = explode('-', date('Y-m-d', strtotime($date)));
    // current week, min 1
    $w = 1;
    // for each day since the start of the month
    for ($i = 1; $i <= $d; ++$i) {
        // if that day was a sunday and is not the first day of month
        if ($i > 1 && date('w', strtotime("$y-$m-$i")) == 0) {
            // increment current week
            ++$w;
        }
    }
    // now return
    return $w;
}

$eventTitle = addslashes(Trim($_POST['eventTitle']));
$startDate = addslashes(Trim($_POST['startDate']));
$endDate = addslashes(Trim($_POST['endDate']));
$recurrenceType = addslashes(Trim($_POST['recurrenceType']));

if(empty($eventTitle))
{
	echo "eventTitle";
	mysqli_close($conn);
}
if(empty($startDate))
{
	echo "startDate";
	mysqli_close($conn);
}
if(empty($endDate))
{
	echo "endDate";
	mysqli_close($conn);
}
if(empty($recurrenceType))
{
	echo "recurrenceType";
	mysqli_close($conn);
}

if($recurrenceType == 1)
{
	$recurrence1week = addslashes(Trim($_POST['recurrence1week']));
	$recurrence1day = addslashes(Trim($_POST['recurrence1day']));
	
	if(empty($recurrence1week))
	{
		$recurrence1week = "";
	}
	if(empty($recurrence1day))
	{
		$recurrence1dayText = "";
	}
	else
	{
		$recurrence1dayText = date('l', strtotime("Sunday +".$recurrence1day." days"));
	}
	
	$recurrence = $recurrence1week." ".$recurrence1dayText;
}
else
{   
    $recurrence2c = addslashes(Trim($_POST['recurrence2c']));
	$recurrence2day = addslashes(Trim($_POST['recurrence2day']));
	$recurrence2month = addslashes(Trim($_POST['recurrence2month']));
	
	if(empty($recurrence2c))
	{
		$recurrence2c = "";
	}
	if(empty($recurrence2day))
	{
		$recurrence2dayText = "";
	}
	else
	{
		$recurrence2dayText = date('l', strtotime("Sunday +".$recurrence2day." days"))."<br>";
	}
	if(empty($recurrence2month))
	{
		$recurrence2month = "";
	}
	
	$recurrence = 'Every '.$recurrence2c." ".$recurrence2dayText. " of the ".$recurrence2month;
}
$checkQuery = mysqli_query($conn, "Select * From tblevents Where eventTitle = '".$eventTitle."'");
$queryResult = mysqli_fetch_assoc($checkQuery);
if(isset($queryResult['eventId'])){
	mysqli_close($conn);
	echo "duplicate";
	exit;
}
else
{
	$query = "Insert into tblevents (eventTitle,startDate,endDate,recurrence,eventAddDateTime) values ('".$eventTitle."','".$startDate."','".$endDate."','".$recurrence."','".$currentDateTime."')";
    mysqli_query($conn, $query) or die(mysqli_error($conn));
    $eventId = mysqli_insert_id($conn);
	
	if($eventId > 0)
	{
		if($recurrenceType == 1)
        {
			    if($recurrence1week == "Every")
				{
					$ofWeek = '';
				}
				elseif ($recurrence1week == "Second")
				{
					$ofWeek = '2';
				}
				elseif ($recurrence1week == "Third")
				{
					$ofWeek = '3';
				}
				//getDateForSpecificDayBetweenDates($startDate,$endDate,$day_number,$ofWeek);
				$dateArr = getDateForDayBetweenDates($startDate,$endDate,$recurrence1day,$ofWeek);
				if (!empty($dateArr))
				{
					foreach ($dateArr as $dates) {
						foreach($dates as $keys => $value) 
						{
							$queryFirst = "select * from tblevents_recurrences where eventId = ".$eventId." and eventDate = '".$value."'";
							$resFirst = mysqli_query($conn,$queryFirst) or die(mysqli_error($conn));
							if(mysqli_num_rows($resFirst) < 1)
							{
								$queryInsert = "insert into tblevents_recurrences (eventId,eventDate,eventDay)values(".$eventId.",'".$value."','".date('l', strtotime("Sunday +".$recurrence1day." days"))."')";
								$resInsert = mysqli_query($conn,$queryInsert) or die(mysqli_error($conn));	
							}
						}
					}
				}		
		} // first Repeat case
		else
		{
			 if($recurrence2c == "First")
				{
					$ofWeek = '1';
				}
				elseif ($recurrence2c == "Second")
				{
					$ofWeek = '2';
				}
				elseif ($recurrence2c == "Third")
				{
					$ofWeek = '3';
				}
				elseif ($recurrence2c == "Forth")
				{
					$ofWeek = '4';
				}
				//getDateForSpecificDayBetweenDates($startDate,$endDate,$day_number,$ofWeek);
				$dateArr = getDateForDayBetweenDates($startDate,$endDate,$recurrence2day,$ofWeek);
				if (!empty($dateArr))
				{
					foreach ($dateArr as $dates) {
						foreach($dates as $keys => $value) 
						{
							$queryFirst = "select * from tblevents_recurrences where eventId = ".$eventId." and eventDate = '".$value."'";
							$resFirst = mysqli_query($conn,$queryFirst) or die(mysqli_error($conn));
							if(mysqli_num_rows($resFirst) < 1)
							{
								$queryInsert = "insert into tblevents_recurrences (eventId,eventDate,eventDay)values(".$eventId.",'".$value."','".date('l', strtotime("Sunday +".$recurrence2day." days"))."')";
								$resInsert = mysqli_query($conn,$queryInsert) or die(mysqli_error($conn));	
							}
						}
					}
				}
				
		}//Repeat of case
	}
	mysqli_close($conn);
	echo "success";
	exit;	
}
?>